# Panduan Deploy — AetherX Telegram Bot

Project ini tidak lagi menggunakan GitHub Releases sebagai sumber versi. Versi dikelola langsung oleh admin Telegram.

## 1. Environment Variables

Tambahkan ke Production:

```text
BOT_TOKEN = token bot dari @BotFather
ADMIN_TELEGRAM_ID = 7633494260
TELEGRAM_WEBHOOK_SECRET = secret random panjang
SETUP_KEY = secret random lain
```

## 2. Hubungkan Vercel Blob

Buat atau hubungkan Vercel Blob Store ke project ini. Katalog versi disimpan di Blob supaya tetap persisten di antara Vercel Function invocations.

Gunakan private Blob untuk katalog. Store baru Vercel dapat menggunakan OIDC sehingga tidak perlu memasukkan token jangka panjang secara manual.

## 3. Deploy production

```bash
vercel --prod
```

## 4. Aktifkan webhook

Buka sekali:

```text
https://DOMAIN-VERCEL-KAMU/api/setup?key=SETUP_KEY_KAMU
```

Pastikan mendapat `"ok": true`.

## 5. Kontrol admin

Admin Telegram dengan ID `7633494260` dapat membuka:

```text
/admin
```

Lalu memilih:

- Upload Versi Terbaru
- Tambah Versi Lama
- Daftar Versi
- Hapus Versi

Untuk versi terbaru, admin dapat memilih sumber `Link` atau `APK / ZIP`. Saat admin mengganti versi terbaru, versi terbaru sebelumnya otomatis masuk ke daftar versi lama.
